%prelab

%1 = D - korrigert
%2 = B - korrigert
%3 = A
%4 = B
%5 = D
%6 = D
%7 = A
%8 = D
%9 = D - korrigert
%10 = B
%11 = C - korrigert

n0 = 1.6583;
nE = 1.4864;
lambda = 589*10^-9;

d = lambda/(2*n0 - 2*nE);

load polarisering1.dat
load polarisering2.dat
load polarisering3.dat

