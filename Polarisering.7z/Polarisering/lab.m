% Rapport Polarisasjon.

%Upolarisert lys

theta = [90 , 80 , 70 , 60 ,50 ,40 ,30 ,20 ,10 ,0];
illum = [249, 250,248,245,241,237,233,231,230,230];

deltaillum = illum.*0.05;

deltatheta = sqrt(ones(1,length(theta)))/length(theta);

figure(1)
errorbar(theta,illum,deltatheta,deltaillum, '-o')
xlabel('\theta')
ylabel('Illuminans, [Lx , 1 lumen pr m^2]')

%malus lov E(theta) - E(90^0), 2 polarisasjonsfiltre
theta2 = 90.0;
theta1 = [0 , 10 , 20 , 30 ,40 ,50 ,60 ,70 ,80 , 90];
I0 = [4,7,20,39,64,92,119,41,156,161];

dtI0 = I0.*0.05;
dtCOS = 0.336;

Intensitet = I0.*cos(theta2 - theta1).^2;

ErrorIi = ( (dtI0./I0).^2 + (dtCOS./Intensitet).^2 ).*(Intensitet.^2); % Usikkerhet I
ErrorI = sqrt(ErrorIi);

figure(2)
errorbar(theta1,Intensitet,deltatheta,ErrorI, '-o')
xlabel('\theta')
ylabel('Intensitet')

% 3 polarisasjonsfiltre, E(0) - E(theta) - E(90)
theta0 = 0.0;
theta2 = 90.0;
theta1 = [0 , 10 , 20 , 30 ,40 ,50 ,60 ,70 ,80 , 90];

I03 = [3,5,11,19,24,24,19,12,5,3];


dtI03 = I03.*0.05;
dtCOS = 0.336;

Intensitet2 = I0.*cos(theta0 -  theta2 - theta1).^2;

ErrorIi2 = ( (dtI03./I03).^2 + (dtCOS./Intensitet2).^2 ).*(Intensitet2.^2); % Usikkerhet I
ErrorI2 = sqrt(ErrorIi2);

figure(3)
errorbar(theta1,Intensitet2,deltatheta,ErrorI2, '-o')
xlabel('\theta')
ylabel('Intensitet')


n = 1.0; % luft
n2 = 2.0%1.3855 glass
degrees = 180/pi

Brewster = atan(n2/n)*degrees;

komp1 = cos(theta).*n2;
komp2 = (1- (sin(theta).*(n/n2)).^2 );


Rp = ( (komp1 - sqrt(komp2) )./ (komp1 + sqrt(komp2) ) ).^2;

  



